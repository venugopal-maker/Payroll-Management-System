@echo off
REM Put mysql-connector-j-8.4.0.jar in lib\, set DB_USER and DB_PASS, then double-click this file.
if not exist out mkdir out
dir /s /b src\*.java > sources.txt
javac -d out @sources.txt
if errorlevel 1 exit /b 1
java -cp "out;lib\*" com.payroll.app.Main
pause
