CREATE DATABASE IF NOT EXISTS payroll_db;
USE payroll_db;

CREATE TABLE IF NOT EXISTS employees (
    emp_id       INT AUTO_INCREMENT PRIMARY KEY,
    name         VARCHAR(100) NOT NULL,
    email        VARCHAR(120) NOT NULL UNIQUE,
    phone        VARCHAR(15),
    department   VARCHAR(60)  NOT NULL,
    designation  VARCHAR(60)  NOT NULL,
    join_date    DATE         NOT NULL,
    basic_salary DECIMAL(12,2) NOT NULL CHECK (basic_salary > 0),
    status       VARCHAR(10)  NOT NULL DEFAULT 'ACTIVE'
);

CREATE TABLE IF NOT EXISTS payroll (
    payroll_id       INT AUTO_INCREMENT PRIMARY KEY,
    emp_id           INT NOT NULL,
    pay_month        TINYINT NOT NULL,
    pay_year         SMALLINT NOT NULL,
    working_days     INT NOT NULL,
    days_absent      INT NOT NULL DEFAULT 0,
    overtime_hours   DECIMAL(6,2) NOT NULL DEFAULT 0,
    basic            DECIMAL(12,2) NOT NULL,
    hra              DECIMAL(12,2) NOT NULL,
    da               DECIMAL(12,2) NOT NULL,
    ta               DECIMAL(12,2) NOT NULL,
    overtime_pay     DECIMAL(12,2) NOT NULL,
    gross_salary     DECIMAL(12,2) NOT NULL,
    pf               DECIMAL(12,2) NOT NULL,
    professional_tax DECIMAL(12,2) NOT NULL,
    income_tax       DECIMAL(12,2) NOT NULL,
    absent_deduction DECIMAL(12,2) NOT NULL,
    total_deductions DECIMAL(12,2) NOT NULL,
    net_salary       DECIMAL(12,2) NOT NULL,
    generated_on     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_emp_month (emp_id, pay_month, pay_year),
    FOREIGN KEY (emp_id) REFERENCES employees(emp_id) ON DELETE CASCADE
);

INSERT IGNORE INTO employees (name,email,phone,department,designation,join_date,basic_salary) VALUES
('Ravi Kumar','ravi@example.com','9876543210','IT','Software Engineer','2024-06-01',40000),
('Sneha Reddy','sneha@example.com','9876501234','HR','HR Executive','2023-11-15',30000),
('Arjun Rao','arjun@example.com','9123456780','Finance','Accountant','2022-01-10',35000);
